# 🖥️ STRAMONT — Plantilla de apuntes

> Importa este archivo en Notion (••• → Import → Markdown) y **duplícalo** para cada clase.

**Materia:**  
**Tema:**  
**Fecha:**  

---

## 🧠 Conceptos core
*(Las ideas principales de la clase, con tus palabras. No copies todo.)*

- 
- 
- 

## 🔑 Palabras clave / disparadores
*(Preguntas que te obliguen a recordar después — autoevaluación.)*

- 
- 

## ❓ Dudas para resolver

- [ ] 
- [ ] 

## 📝 Resumen en 3 frases
*(Te obliga a comprender, no solo a copiar.)*

1. 
2. 
3. 

---

### 🔁 Repaso espaciado
- [ ] Hoy
- [ ] En 2 días
- [ ] En 1 semana

---
*STRAMONT · Aprende más en menos tiempo · montaguth.institute*
